"""Envelope Q-Learning (EQL) implementation."""
