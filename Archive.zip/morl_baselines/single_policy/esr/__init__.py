"""ESR Algorithms."""
